package logic;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LoadData {
    List<String> logins = new ArrayList<>();
    List<String> passwords = new ArrayList<>();
    List <String> properties = new ArrayList<>();
    List <Integer> sold = new ArrayList<>();
    List<Integer> max = new ArrayList<>();

    List<String>modification = new ArrayList<>();
    public LoadData(){

        try {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\mati8\\Desktop\\untitled\\src\\data"));
            String line;
            while ((line = br.readLine()) != null){
                String [] buff = line.split(",");
                logins.add(buff[0].trim());
                passwords.add(buff[1].trim());

            }
            br.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            BufferedReader br2 = new BufferedReader(new FileReader("C:\\Users\\mati8\\Desktop\\untitled\\src\\properties"));
            String line;
            while((line = br2.readLine()) != null){
                String [] buff = line.split(";");
                properties.add(buff[0]);
                sold.add(Integer.parseInt(buff[1]));
                max.add(Integer.parseInt(buff[2]));

            }
            br2.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }




    }

    public void loadModification(){
        try {
            BufferedReader br3 = new BufferedReader(new FileReader("C:\\Users\\mati8\\Desktop\\untitled\\src\\modification.txt"));
            String line;
            List<String> buff = new ArrayList<>();
            while ((line = br3.readLine()) != null){
                if ("{".equals(line)) {
                    continue;
                } else if ("}".equals(line)) {
                    String info = String.join(" ", buff );
                    modification.add(info);
                    buff.clear();
                    continue;

                }
                buff.add(line);

            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public List<String> getLogins(){
        return logins;
    }
    public List<String> getPasswords(){
        return passwords;
    }
    public List<String> getProperties(){
        return properties;
    }

    public List<Integer> getSold(){
        return sold;
    }

    public List<Integer> getMax(){
        return max;
    }

    public List<String> getModification(){
        return modification;
    }

}
