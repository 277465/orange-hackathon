package main;

import graph.Frame;
import graph.StartPanel;
import graph.start_menu.buttons.Login;
import graph.start_menu.labels.JAM;
import graph.start_menu.textfields.Logs;
import logic.LoadData;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        Main main = new Main();
        LoadData loadData = new LoadData();
        main.makeGui(loadData);
    }


    private void makeGui(LoadData loadData){
        Frame frame = new Frame();
        StartPanel startPanelClass = new StartPanel(frame.getFrame());
        JPanel startPanel = startPanelClass.getStartPanel();
        JAM jamLabel = new JAM(startPanel);
        Logs logs = new Logs(startPanel);
        Login login = new Login(startPanel,logs,loadData, frame.getFrame());
    }
}
