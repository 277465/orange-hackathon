package graph.start_menu.buttons;

import graph.admin_view.AdminPanel;
import graph.admin_view.OpenAdminView;
import graph.start_menu.labels.WrongLogin;
import graph.start_menu.textfields.Logs;
import graph.user_view.OpenUserView;
import logic.LoadData;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Login {

    JButton button = new JButton("Zaloguj");
    private boolean loginAccepted = false;

    public Login(JPanel panel, Logs logs, LoadData loadData, JFrame frame){
        button.setBounds(190,200,80,20);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> logins = loadData.getLogins();
                List<String> passwords = loadData.getPasswords();
                String [] data = new String[2];
                data = logs.getDatas();
                String login = data[0];
                String password =  data[1];

                for(int i = 0; i<logins.size(); i++){
                    if(login.equals(logins.get(i))){
                            if(password.equals(passwords.get(i))){
                                loginAccepted = true;
                                break;
                            }
                    }
                }
                if(loginAccepted){
                    for (Component comp : panel.getComponents()) {
                        if (comp instanceof JLabel && "wrongLogin".equals(comp.getName())) {
                            panel.remove(comp);
                        }
                    }
                    panel.revalidate();
                    panel.repaint();


                    frame.remove(panel);
                    if(login.equals("admin123")) {
                        OpenAdminView openAdminView = new OpenAdminView(frame, loadData, login);
                    }
                    else{
                        OpenUserView openUserView = new OpenUserView(frame, login);
                    }

                }
                else{
                    for (Component comp : panel.getComponents()) {
                        if (comp instanceof JLabel && "wrongLogin".equals(comp.getName())) {
                            panel.remove(comp);
                        }
                    }
                    WrongLogin wrongLogin = new WrongLogin(panel);
                    panel.revalidate();
                    panel.repaint();
                }

            }
        });


        panel.add(button);

        panel.revalidate();
        panel.repaint();
    }


}
