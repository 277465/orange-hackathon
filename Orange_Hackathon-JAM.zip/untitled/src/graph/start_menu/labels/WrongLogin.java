package graph.start_menu.labels;

import javax.swing.*;
import java.awt.*;

public class WrongLogin {
    JLabel wrongLogin = new JLabel("Błędny login lub hasło");

    public WrongLogin(JPanel panel){

        wrongLogin.setName("wrongLogin");

        wrongLogin.setFont(new Font("Arial", Font.BOLD, 15));

        wrongLogin.setForeground(Color.RED);

        wrongLogin.setBounds(160,250, 300,20);

        panel.add(wrongLogin);

        panel.revalidate();
        panel.repaint();
    }
}
