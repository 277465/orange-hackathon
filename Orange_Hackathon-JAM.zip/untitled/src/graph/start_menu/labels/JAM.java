package graph.start_menu.labels;

import javax.swing.*;
import java.awt.*;

public class JAM {

     JLabel jam= new JLabel("WITAJ W APLIKACJI JAM");

    public JAM(JPanel panel){
        jam.setFont(new Font("Arial", Font.BOLD, 40));

        jam.setBounds(1,10,600,30);

        panel.add(jam);
        panel.revalidate();
        panel.repaint();
    }

}
