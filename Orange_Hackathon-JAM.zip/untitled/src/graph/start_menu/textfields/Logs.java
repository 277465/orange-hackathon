package graph.start_menu.textfields;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class Logs {
    JTextField login = new JTextField();
    JPasswordField password = new JPasswordField();

    public Logs(JPanel panel){

        login.setBounds(160,140,140,20);
        password.setBounds(160,170,140,20);

        login.setForeground(Color.GRAY);
        password.setForeground(Color.GRAY);


        login.setText("login");
        login.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (login.getText().equals("login")) {
                    login.setText("");
                    login.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (login.getText().isEmpty()) {
                    login.setText("login");
                    login.setForeground(Color.GRAY);
                }
            }
        });

        char defaultEchoChar;

        defaultEchoChar = password.getEchoChar();
        password.setForeground(Color.GRAY);
        password.setEchoChar((char) 0);
        password.setText("hasło");

        password.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (new String(password.getPassword()).equals("hasło")) {
                    password.setText("");
                    password.setForeground(Color.BLACK);
                    password.setEchoChar(defaultEchoChar);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (password.getPassword().length == 0) {
                    password.setText("hasło");
                    password.setForeground(Color.GRAY);
                    password.setEchoChar((char) 0);
                }
            }
        });

        panel.add(login);
        panel.add(password);


        panel.revalidate();
        panel.repaint();
    }

    public String [] getDatas(){
        String [] datas = new String[2];
        datas[0] = login.getText();
        datas[1] = password.getText();

        return datas;
    }


}
