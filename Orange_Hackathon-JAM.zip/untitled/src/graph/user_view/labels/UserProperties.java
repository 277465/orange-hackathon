package graph.user_view.labels;

import javax.swing.*;

public class UserProperties {

    JLabel label = new JLabel("Twoje nieruchomości");

    public UserProperties(JPanel panel){

        label.setBounds(5,5, 150,20);

        panel.add(label);


    }

}
