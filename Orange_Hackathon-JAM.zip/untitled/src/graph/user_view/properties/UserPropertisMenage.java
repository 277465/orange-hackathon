package graph.user_view.properties;

import graph.admin_view.properties.PropertiesMenago;
import logic.LoadData;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class UserPropertisMenage {
    JLabel label = new JLabel();
    PropertiesMenago propertiesMenago;

    public UserPropertisMenage(JPanel panel, int y, String name, String user){

        LoadData loadData = new LoadData();
        propertiesMenago = new PropertiesMenago(name);

        label.setText(name + "  |  10/50");



        JButton button = new JButton("Zarządzaj");

        label.setBounds(5,y,210,20);
        button.setBounds(370,y, 100,20);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData.loadModification();
                List<String> allModification = loadData.getModification();

                List<String>userModification = new ArrayList<>();
                boolean isAnyModify = false;

                for(int i = 0; i< allModification.size(); i++){
                    if(allModification.get(i).contains(name)){
                        userModification.add(allModification.get(i));
                        isAnyModify =  true;
                    }
                }
                propertiesMenago.menageButtonAction(name, userModification, isAnyModify, user );
            }
        });

        panel.add(label);
        panel.add(button);

    }




}
