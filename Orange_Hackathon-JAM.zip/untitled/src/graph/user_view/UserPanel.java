package graph.user_view;

import javax.swing.*;

public class UserPanel {

    JPanel userPanel = new JPanel();

    public UserPanel(JFrame frame){

        userPanel.setLayout(null);
        frame.add(userPanel);
    }

}
