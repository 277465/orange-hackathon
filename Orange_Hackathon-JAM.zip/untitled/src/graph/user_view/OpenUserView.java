package graph.user_view;

import graph.user_view.properties.UserPropertisMenage;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OpenUserView {

    List<String> name = new ArrayList<>();

    public OpenUserView(JFrame frame, String user){
        UserPanel userPanelClass = new UserPanel(frame);
        JPanel userPanel = userPanelClass.userPanel;

        int y = 25;

        try {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\mati8\\Desktop\\untitled\\src\\properties"));

            String line;

            while((line = br.readLine()) != null){
            String [] buf = line.split(";");
            String user1 = buf[3];
            String [] owners = user1.split(",");

            for(int j = 0; j<owners.length; j++){
                if(owners[j].equals(user)){
                    name.add(buf[0]);
                    break;
                }

            }
            }
            br.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        for(int i = 0; i<name.size(); i++){
            UserPropertisMenage userPropertisMenage = new UserPropertisMenage(userPanel,y, name.get(i), user);

            y = y+35;
        }

    }


}
