package graph.admin_view.labels;

import javax.swing.*;

public class Properties {
    JLabel properties = new JLabel("Twoje nieruchomości: ");

    public Properties(JPanel panel){

        properties.setBounds(5,5,150,20);

        panel.add(properties);
        panel.revalidate();
        panel.repaint();

    }
}
