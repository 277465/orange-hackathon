package graph.admin_view.properties;

import logic.LoadData;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PropertiesMenago {
    JLabel prop = new JLabel();
    LoadData loadData = new LoadData();
    public PropertiesMenago(String name){

    }

    public PropertiesMenago(JPanel panel, int y, String name, int sell, int max, List<Integer> sold, List<Integer> maximum, int i, String userName){
        prop.setText(name + "   " + sell+"/"+ max );
        prop.setBounds(5,y,260,20);

        JButton menage = new JButton("Zarządzaj");
        JButton sellButton = new JButton("Sprzedaj");

        if(sell == max){
            sellButton.setEnabled(false);
        }


        sellButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                selButtonAction(i, sold, maximum, name, panel, sellButton);

            }
        });


        menage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData.loadModification();
                List<String>allModification = loadData.getModification();
                List<String>userModification = new ArrayList<>();
                boolean isAnyModify = false;

                for(int i = 0; i< allModification.size(); i++){
                    if(allModification.get(i).contains(name)){
                        userModification.add(allModification.get(i));
                        isAnyModify =  true;
                    }
                }

                menageButtonAction(name,userModification, isAnyModify, userName);
            }
        });





        menage.setBounds(240,y, 100,20);
        sellButton.setBounds(360,y, 100,20);
        panel.add(prop);
        panel.add(menage);
        panel.add(sellButton);

        panel.revalidate();
        panel.repaint();

    }

    protected void selButtonAction(int i, List<Integer> sold, List<Integer> max, String data, JPanel panel, JButton sellButton ){
        JFrame sellFrame = new JFrame();
        sellFrame.setSize(400,200);
        JPanel sellPanel = new JPanel();
        sellPanel.setLayout(null);


        JLabel fraction = new JLabel("Część całości");
        fraction.setBounds(70,10,80,20);
        sellPanel.add(fraction);

        JTextField fracChoice = new JTextField();
        fracChoice.setBounds(95,50,40,20);
        sellPanel.add(fracChoice);


        JLabel customer = new JLabel("Dane kupującego");
        customer.setBounds(220,10,100,20);
        sellPanel.add(customer);

        JTextField name = new JTextField();
        JTextField surname = new JTextField();

        name.setForeground(Color.GRAY);
        surname.setForeground(Color.GRAY);

        name.setBounds(220,40,100,20);
        surname.setBounds(220,70,100,20);

        sellPanel.add(name);
        sellPanel.add(surname);


        name.setText("Imie");
        surname.setText("Nazwisko");

        {

            name.addFocusListener(new FocusListener() {
                @Override
                public void focusGained(FocusEvent e) {
                    if (name.getText().equals("Imie")) {
                        name.setText("");
                        name.setForeground(Color.BLACK);
                    }

                }

                @Override
                public void focusLost(FocusEvent e) {
                    if (name.getText().isEmpty()) {
                        name.setText("Imie");
                        name.setForeground(Color.GRAY);
                    }
                }
            });

            surname.addFocusListener(new FocusListener() {
                @Override
                public void focusGained(FocusEvent e) {
                    if (surname.getText().equals("Nazwisko")) {
                        surname.setText("");
                        surname.setForeground(Color.BLACK);
                    }

                }

                @Override
                public void focusLost(FocusEvent e) {
                    if (surname.getText().isEmpty()) {
                        surname.setText("Nazwisko");
                        surname.setForeground(Color.GRAY);
                    }
                }
            });

        }




        JButton confirm = new JButton("Zatwierdz");
        confirm.setBounds(130,130,100,20);

        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                for(Component com : sellPanel.getComponents()){
                    if("TooMuch".equals(com.getName())){
                        sellPanel.remove(com);
                    }
                }

                int currentSold = sold.get(i);
                int maximum = max.get(i);
                int addedSold = Integer.parseInt(fracChoice.getText());

                if(currentSold+addedSold > maximum){
                JLabel label = new JLabel("Przypisujesz zbyt dużą część niż jest to możliwe");
                label.setName("TooMuch");
                label.setForeground(Color.RED);

                label.setBounds(60,100,300,20);

                sellPanel.add(label);
                sellPanel.revalidate();
                sellPanel.repaint();



                }

                else {
                    int curretnUser = currentSold+addedSold;
                    sold.set(i,curretnUser);
                    prop.setText(data + "   " + curretnUser+"/"+ maximum);

                    panel.revalidate();
                    panel.repaint();

                    if(curretnUser == maximum){
                        sellButton.setEnabled(false);
                    }

                }

            }
        });

        sellPanel.add(confirm);

        sellFrame.setLocationRelativeTo(null);
        sellFrame.add(sellPanel);
        sellFrame.setVisible(true);

    }


    public void menageButtonAction(String name, List<String> userModify, boolean isAnyModify, String user){

        JFrame frame = new JFrame();
        frame.setLocationRelativeTo(null);
        frame.setSize(500,500);

        JPanel menagePanel = new JPanel();
        menagePanel.setLayout(null);

        if(!isAnyModify) {
            JLabel noNotification = new JLabel("<html><pre style='font-family: Arial; font-size: 9px;' >Brak nowych powiadomień\n  dotyczących posiadłości</pre></html>");
            noNotification.setName("noNotify");
            noNotification.setBounds(160, 190, 180, 60);
            menagePanel.add(noNotification);
        }
        else{
            for(Component component : menagePanel.getComponents()){
                if("noNotify".equals(component.getName())){
                    menagePanel.remove(component);
                }
            }

            int y = 10;
            for(int i = 0; i<userModify.size(); i++){
                String data = userModify.get(i);
                String [] buff = data.split(";");
                JLabel modifications = new JLabel("<html>Rodzaj: " + buff[1] + "<br>Dodatkowe informacje : " + buff[2] +
                        "<br>Użytkownik proponujący zmiane : " + buff[3] +"</html>");


                modifications.setBounds(5,y,500,120);
                menagePanel.add(modifications);
                JButton accept = new JButton("Akceptuj");
                JButton reject = new JButton("Odrzuć");

                accept.setBounds(380,y+35, 100,20);
                reject.setBounds(380,y+60,100,20);

                menagePanel.add(accept);
                menagePanel.add(reject);

                y = y+100;


                {
                    accept.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            acceptButtonAction(accept,reject);
                        }
                    });

                    reject.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            accept.setEnabled(false);
                            reject.setEnabled(false);
                        }
                    });


                }
            }





        }

        JButton modificationButton = new JButton("Zaproponuj zmiane");
        modificationButton.setBounds(160,430,150,20);

        modificationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame modificationFrame = new JFrame();

                modificationFrame.setSize(300,350);

                JPanel modificationPanel = new JPanel();
                modificationPanel.setLayout(null);

                JTextField typeOfChange = new JTextField();
                typeOfChange.setForeground(Color.GRAY);
                typeOfChange.setText("Rodzaj zmiany");
                typeOfChange.setBounds(45,15,200,20);

                typeOfChange.addFocusListener(new FocusListener() {
                    @Override
                    public void focusGained(FocusEvent e) {
                        if (typeOfChange.getText().equals("Rodzaj zmiany")) {
                            typeOfChange.setText("");
                            typeOfChange.setForeground(Color.BLACK);
                        }
                    }

                    @Override
                    public void focusLost(FocusEvent e) {
                        if (typeOfChange.getText().isEmpty()) {
                            typeOfChange.setText("Rodzaj zmiany");
                            typeOfChange.setForeground(Color.GRAY);
                        }
                    }
                });

                JTextArea info = new JTextArea();
                info.setForeground(Color.GRAY);
                info.setText("Dodatkowe informacje");
                info.setBounds(5,50,278,200);

                info.addFocusListener(new FocusListener() {
                    @Override
                    public void focusGained(FocusEvent e) {
                        if (info.getText().equals("Dodatkowe informacje")) {
                            info.setText("");
                            info.setForeground(Color.BLACK);
                        }
                    }

                    @Override
                    public void focusLost(FocusEvent e) {
                        if (info.getText().isEmpty()) {
                            info.setText("Dodatkowe informacje");
                            info.setForeground(Color.GRAY);
                        }
                    }
                });


                JButton confirm = new JButton("Zatwierdź");
                confirm.setBounds(95,270,100,20);

                confirm.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nameOfPlace = name;
                        String type = typeOfChange.getText();
                        String informations = info.getText();

                        String toWrite = nameOfPlace+";"+type+";"+informations+";"+user;

                        try {
                            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\mati8\\Desktop\\untitled\\src\\modification.txt",
                                    true));
                            bw.write("{\n"+toWrite+"\n}\n");

                            bw.close();

                            modificationFrame.setVisible(false);

                        } catch (FileNotFoundException ex) {
                            throw new RuntimeException(ex);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }


                });





                modificationPanel.add(typeOfChange);
                modificationPanel.add(info);
                modificationPanel.add(confirm);

                modificationFrame.setLocationRelativeTo(null);
                modificationFrame.add(modificationPanel);
                modificationFrame.setVisible(true);
            }
        });

        //menagePanel.add(noNotification);
        menagePanel.add(modificationButton);




        frame.add(menagePanel);

        frame.setVisible(true);

    }

    protected void acceptButtonAction(JButton accept2, JButton reject){
        //SMS FRAME

            Frame smsFrame = new JFrame("SMS");

            JPanel smsPanel = new JPanel();

            int[] randomNumbers = new int[6];

            for (int i = 0; i < 6; i++) {
                Random random = new Random();
                int number = random.nextInt(10);
                randomNumbers[i] = number;
            }
            JLabel sms = new JLabel("sms");
            sms.setFont(new Font("Arial", Font.BOLD, 15));
            JLabel password = new JLabel(String.valueOf(randomNumbers[0]) + " " + String.valueOf(randomNumbers[1]) + " " +
                    String.valueOf(randomNumbers[2]) + " " + String.valueOf(randomNumbers[3]) + " " + String.valueOf(randomNumbers[4]) + " " +
                    String.valueOf(randomNumbers[5]));

            password.setFont(new Font("Arial", Font.BOLD, 25));
            password.setBounds(5, 5, 200, 100);

            sms.setBounds(50, 0, 50, 50);

            smsPanel.add(sms);

            smsPanel.setLayout(null);
            smsPanel.add(password);

            smsFrame.setSize(150, 120);
            smsFrame.setLocation(100,100);
            smsFrame.add(smsPanel);
            smsFrame.setVisible(true);

        //PASSWORD FRAME

        JFrame passwordFrame = new JFrame();
        JPanel passwordPanel = new JPanel();

        passwordPanel.setLayout(null);

        passwordFrame.setLocationRelativeTo(null);
        passwordFrame.setSize(150,200);

        JLabel writePassword = new JLabel("Podaj otrzymany kod");
        writePassword.setBounds(10,5,200,20);

        passwordPanel.add(writePassword);

        JTextField pas = new JTextField();
        pas.setBounds(30,50,70,20);
        passwordPanel.add(pas);

        JButton accept = new JButton("Potwierdź");
        accept.setBounds(15,100,100,20);

        accept.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int userPassword =  Integer.parseInt(pas.getText());
                int [] key = new int[6];

                for(int i = 5; i>=0; i--){
                    key[i] = userPassword%10;
                    userPassword = userPassword/10;
                }
                int counter = 0;
                for(int i = 0; i<6; i++){
                    if(key[i] == randomNumbers[i] ){
                        counter++;
                    }
                }
                boolean correctKey = false;
                if(counter == 6){
                    correctKey = true;
                }

                if(correctKey){
                    passwordFrame.setVisible(false);
                    accept2.setEnabled(false);
                    reject.setEnabled(false);

                }
                else{
                    JLabel wrongKey = new JLabel("Błędny kod");
                    wrongKey.setForeground(Color.RED);
                    wrongKey.setBounds(30,75,100,20);

                    passwordPanel.add(wrongKey);

                    passwordPanel.revalidate();
                    passwordPanel.repaint();
                }
            }
        });



        passwordPanel.add(accept);

        passwordFrame.add(passwordPanel);

        passwordFrame.setVisible(true);


    }


}
