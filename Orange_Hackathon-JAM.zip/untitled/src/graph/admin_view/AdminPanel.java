package graph.admin_view;

import javax.swing.*;

public class AdminPanel {
    JPanel adminPanel = new JPanel();

    public AdminPanel(JFrame frame){
        adminPanel.setLayout(null);
        frame.add(adminPanel);
    }
}
