package graph.admin_view;

import graph.admin_view.labels.Properties;
import graph.admin_view.properties.PropertiesMenago;
import logic.LoadData;

import javax.swing.*;
import java.util.List;

public class OpenAdminView {

    public OpenAdminView(JFrame frame, LoadData loadData, String user){

        List<String> name = loadData.getProperties();
        List<Integer> sell = loadData.getSold();
        List<Integer> max = loadData.getMax();
        String userName = user;

        int y = 45;

        AdminPanel adminPanelClass = new AdminPanel(frame);
        JPanel adminPanel = adminPanelClass.adminPanel;
        Properties properties = new Properties(adminPanel);


        for(int i = 0; i<name.size(); i++){
            PropertiesMenago propertiesMenago = new PropertiesMenago(adminPanel, y ,name.get(i), sell.get(i), max.get(i), sell, max, i, userName);

            y = y+35;
        }

    }

}
