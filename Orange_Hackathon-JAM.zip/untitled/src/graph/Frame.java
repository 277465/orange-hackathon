package graph;

import javax.swing.*;

public class Frame {
    JFrame frame = new JFrame("JAM APP");


    public Frame(){

        frame.setLocationRelativeTo(null);
        frame.setSize(500,500);
        frame.setVisible(true);
    }

    public JFrame getFrame(){
        return frame;
    }
}
