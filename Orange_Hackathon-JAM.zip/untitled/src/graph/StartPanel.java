package graph;

import javax.swing.*;

public class StartPanel {

    JPanel startPanel = new JPanel();

    public StartPanel(JFrame frame){

        startPanel.setLayout(null);
        frame.add(startPanel);




    }

    public JPanel getStartPanel(){
        return startPanel;
    }


}
